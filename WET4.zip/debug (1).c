

#include <sys/wait.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <errno.h>
#include <unistd.h>
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/user.h>
#include "elf64.h"
#include <stdio.h>

void exitIfSyscallFailed(int val)
{
    if(val<0)
    {
        exit(1);
    }
}

void checkItsElfFile(FILE* file,Elf64_Ehdr header)
{
    if( !(header.e_ident[0] == 0x7f &&
          header.e_ident[1] == 'E'  &&
          header.e_ident[2] == 'L'  &&
          header.e_ident[3] == 'F'))
    {
        fclose(file);
        exit(1);
    }
}

void checkFileOpened(FILE* file)
{
    if(!file)
    {
        exit(1);
    }
}

//current_section==curr_sec,
//section_header_size==sec_header_len

Elf64_Shdr getSymbolTableHeader(FILE* file,Elf64_Ehdr header)
{
    Elf64_Shdr curr_sec;
    exitIfSyscallFailed(fseek(file, header.e_shoff,SEEK_SET));
    Elf64_Half sec_header_len = header.e_shentsize;
    for (int i = 0; i < header.e_shnum ; i++)
    {
        exitIfSyscallFailed(fread(&curr_sec, sec_header_len , 1, file));
        if(curr_sec.sh_type == 2)
        {
            return curr_sec;
        }
    }
}

void updateStringTableHeader(Elf64_Shdr sym_tab_header,FILE* file,Elf64_Ehdr header,Elf64_Shdr* str_tab_header)
{
    int string_table_entry_num = sym_tab_header.sh_link;
    Elf64_Half sec_header_len = header.e_shentsize;
    exitIfSyscallFailed(fseek(file, header.e_shoff + string_table_entry_num * sec_header_len ,SEEK_SET));
    exitIfSyscallFailed(fread(str_tab_header, sec_header_len, 1, file));
}


Elf64_Xword getNumOfEntriesInSymTab(Elf64_Shdr sym_tab_header, Elf64_Xword* symtab_entry_len)
{
    *symtab_entry_len = sym_tab_header.sh_entsize;
    Elf64_Xword symtab_len = sym_tab_header.sh_size;
    return symtab_len / *symtab_entry_len;
}

//exe_file==file, elf_header==header,
//symbol_table_header==sym_tab_header
//str_table_header==str_tab_header
//symtab_num_of_entries==symtab_entries_amount
long find_symbol(const char* symbol_name, const char* exe_file_name, unsigned int* local_count)
{
    FILE* file=fopen(exe_file_name, "rb");
    checkFileOpened(file);
    Elf64_Ehdr header;
    exitIfSyscallFailed(fread(&header, sizeof(header), 1, file));
    checkItsElfFile(file, header);
    int local=0;

    //check if it's exe
    if (header.e_type != 2)
    {
        fclose(file);
        return -3;
    }

    Elf64_Shdr sym_tab_header=getSymbolTableHeader(file, header);
    Elf64_Shdr str_tab_header;
    updateStringTableHeader(sym_tab_header, file, header,&str_tab_header);

    //copying string table just in case (so we don't ruin original data)
    char* dup= malloc(sizeof(char)*str_tab_header.sh_size);
    if(!dup)
    {
        fclose(file);
        exit(1);
    }
    exitIfSyscallFailed(fseek(file, str_tab_header.sh_offset, SEEK_SET));
    exitIfSyscallFailed(fread(dup, str_tab_header.sh_size, 1, file));

    Elf64_Xword symtab_entry_len;
    Elf64_Xword symtab_entries_amount=getNumOfEntriesInSymTab(sym_tab_header, &symtab_entry_len);

    Elf64_Sym curr_symtab_entry;
    const char* curr_sym_name = NULL;
    bool symbol_exist = 0;

    exitIfSyscallFailed(fseek(file, sym_tab_header.sh_offset, SEEK_SET));
    for(int i=0 ; i < symtab_entries_amount ; i++)
    {
        exitIfSyscallFailed(fread(&curr_symtab_entry, symtab_entry_len, 1, file));
        curr_sym_name= dup+curr_symtab_entry.st_name;
        int different=strcmp(curr_sym_name, symbol_name);
        if(!different)
        {
            symbol_exist=true;
            if (ELF64_ST_BIND(curr_symtab_entry.st_info) == 1)
            {
                Elf64_Addr symbol_val = curr_symtab_entry.st_value;
                fclose(file);
                free(dup);
                return symbol_val; //it's global so we return func address
            }
            if (ELF64_ST_BIND(curr_symtab_entry.st_info) == 0)
            {
                local++;
            }
        }
    }

    fclose(file);
    free(dup);

    if(!symbol_exist)
    {
        return -1;
    }

    *local_count=local;
    return -2; //if we got here- symbol was found and wasn't global, hence it's local
}

void helpPtrace (enum __ptrace_request what_to_do, pid_t pid, void* address, void* data){
    long res = ptrace(what_to_do, pid, address, data);

    if (res == -1){
        exit(1);
    }
}

pid_t runTheProg(const char* prog_name, char* const* param){

    pid_t pid = fork();

    if (pid > 0) //father
    {
        return pid;
    }
    else if (pid <0) //either son or error, and pid<0=>error
    {
        perror("fork");
        exit(1);
    }
    else
    {
        helpPtrace(PTRACE_TRACEME, 0, NULL, NULL);
        exitIfSyscallFailed(execv(prog_name, param));
    }
    return -1; //shouldn't get here
}

bool Isbreakpoint(pid_t child_pid, struct user_regs_struct* regs, long  func_add,int* stat)
{
    helpPtrace(PTRACE_GETREGS, child_pid, 0, regs);
    if(regs->rip-1!=func_add)
    {
        helpPtrace(PTRACE_CONT, child_pid, NULL, NULL);
        wait(stat);
        return false; //not breakpoint
    }
    return true;
}

long ptraceForDebug(enum __ptrace_request req, pid_t pid, void* address, void* data){
    long res = ptrace(req, pid, address, data);
    if (res == -1){
        exit(1);
    }

    return res;
}

//original_inst=old_data
//trap_inst=insert1
void debugMode(long func_add, pid_t child_pid)
{
    int stat;
    struct user_regs_struct regs;
    wait(&stat);
    unsigned long old_data = ptraceForDebug(PTRACE_PEEKTEXT, child_pid, (void*)func_add, NULL);
    unsigned long insert1 = old_data & 0xFFFFFFFFFFFFFF00;
    insert1= insert1 | 0xCC;
    helpPtrace(PTRACE_POKETEXT, child_pid, (void*)func_add, (void*)insert1);
    helpPtrace(PTRACE_CONT, child_pid, NULL, NULL);
    wait(&stat);


    while (WIFSTOPPED(stat))
    {
        if(!Isbreakpoint(child_pid, &regs, func_add,&stat))
        {
            continue;
        }

        //if we are here than we are at the bp
        unsigned long address_of_ret_add = regs.rsp;
        unsigned long return_address = ptraceForDebug(PTRACE_PEEKTEXT, child_pid, (void*)address_of_ret_add, NULL);
        unsigned long data_to_be_overun = ptraceForDebug(PTRACE_PEEKTEXT, child_pid, (void*)return_address, NULL);
        unsigned long insert2 = data_to_be_overun & 0xFFFFFFFFFFFFFF00;
        insert2=insert2 | 0xCC;
        helpPtrace(PTRACE_POKETEXT, child_pid, (void*)return_address, (void*)insert2); //we only want to debug the given func, so we want to stop once we get to ret_add- the reason for the breakpoint
        helpPtrace(PTRACE_POKETEXT, child_pid, (void*)func_add, (void*)old_data);//removing first breakpoint
        regs.rip--; //we go backwards to the start of the given func - now we debug it
        helpPtrace(PTRACE_SETREGS, child_pid, 0, &regs);

        while(1)//debug till the program ends
        {
            helpPtrace(PTRACE_SYSCALL, child_pid, NULL, NULL);
            wait(&stat);
            helpPtrace(PTRACE_GETREGS, child_pid, 0, &regs);

            if(regs.rip-1==return_address) //in this case we're at ret address
            {
                if(address_of_ret_add!=regs.rsp-sizeof (uint64_t)) //we are there as part of our func that hasn't ended yet
                {
                    helpPtrace(PTRACE_POKETEXT, child_pid, (void*)return_address, (void*)data_to_be_overun);
                    regs.rip--;
                    helpPtrace(PTRACE_SETREGS, child_pid, 0, &regs);
                    unsigned char part1_of_opcode = data_to_be_overun & 0xFF;
                    unsigned char part2_of_opcode = data_to_be_overun & 0xFF00;
                    part2_of_opcode= part2_of_opcode >> 8;
                    bool cond1=(part1_of_opcode == 0x0F && part2_of_opcode == 0x05);
                    bool cond2=(part1_of_opcode == 0xCD && part2_of_opcode == 0x80)  ;
                    if(cond1 || cond2)
                    {
                        helpPtrace(PTRACE_SYSCALL, child_pid, NULL, NULL);
                        wait(&stat);
                        helpPtrace(PTRACE_SYSCALL, child_pid, NULL, NULL);
                        wait(&stat);
                        helpPtrace(PTRACE_GETREGS, child_pid, 0, &regs);
                        if ((long)regs.rax < 0) //syscall failed
                        {
                            printf("PRF:: the syscall in 0x%llx returned with %lld\n", regs.rip-2, regs.rax);
                        }
                        helpPtrace(PTRACE_POKETEXT, child_pid, (void*)return_address, (void*)insert2);
                        continue;
                    }
                    else
                    {
                        helpPtrace(PTRACE_SINGLESTEP, child_pid, NULL, NULL);
                        wait(&stat);
                        helpPtrace(PTRACE_POKETEXT, child_pid, (void*)return_address, (void*)insert2);
                        continue;
                    }
                }

                helpPtrace(PTRACE_POKETEXT, child_pid, (void*)return_address, (void*)data_to_be_overun);//if we are here than we are at ret add cause the son ended his func
                regs.rip--;
                helpPtrace(PTRACE_SETREGS, child_pid, 0, &regs);
                break; // son has ended its run
            }

            else //we're not at ret add - func is still ongoing
            {
                helpPtrace(PTRACE_SYSCALL, child_pid, NULL, NULL);
                wait(&stat);
                if(WIFEXITED(stat)) return;
                helpPtrace(PTRACE_GETREGS, child_pid, 0, &regs);
                if ((long)regs.rax < 0) //sys failed
                {
                    printf("PRF:: the syscall in 0x%llx returned with %lld\n", regs.rip-2, regs.rax);
                }
            }

        }

        helpPtrace(PTRACE_POKETEXT, child_pid, (void*)func_add, (void*)insert1);//remove BP
        helpPtrace(PTRACE_CONT, child_pid, NULL, NULL); //let the son continue is his other funcs
        wait(&stat);
    }
    return;
}


//function_to_debgug==requested_to_debug
//exe_file_name==file_name
//exe_file_parameters==file_parameters
int main(int argc, char const **argv)
{

    const char* requested_to_debug = argv[1];
    const char* file_name = argv[2];
    char* const* file_parameters = (char* const*)(argv + 2);
    unsigned int local_count = 0;

    long res = find_symbol(requested_to_debug, file_name, &local_count);

    if (res == -3){
        printf("PRF:: %s not an executable!\n", file_name);
        return 0;
    }
    if (res == -1){
        printf("PRF:: %s not found!\n", requested_to_debug);
        return 0;
    }
    if (res == -2){
        printf("PRF:: %s is a local symbol %d times!\n",requested_to_debug, local_count);
        return 0;
    }

    // if reached here we can debug
    long func_add = res;
    pid_t child_pid = runTheProg(file_name, file_parameters);
    debugMode(func_add, child_pid);

    return 0;
}




















